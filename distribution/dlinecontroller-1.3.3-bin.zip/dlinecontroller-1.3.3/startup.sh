#!/bin/sh
java -classpath "dlinecontroller-1.3.3.jar" org.lz1aq.dlinecontroller.DLineApplication