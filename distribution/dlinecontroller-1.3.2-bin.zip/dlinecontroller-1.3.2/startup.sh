#!/bin/sh
java -classpath "dlinecontroller-1.3.1.jar" org.lz1aq.dlinecontroller.DLineApplication