#!/bin/sh
java -classpath "dlinecontroller-1.6.jar" org.lz1aq.dlinecontroller.DLineApplication