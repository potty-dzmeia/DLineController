#!/bin/sh
java -classpath "dlinecontroller-1.4.jar" org.lz1aq.dlinecontroller.DLineApplication